package com.tcs.user_service.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.tcs.user_service.Entity.User;

public interface UserRepository extends JpaRepository<User, Long> {

}