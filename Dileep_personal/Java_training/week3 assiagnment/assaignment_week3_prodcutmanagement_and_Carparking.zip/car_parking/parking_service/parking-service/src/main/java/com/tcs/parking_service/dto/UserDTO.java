package com.tcs.parking_service.dto;


public class UserDTO {

    private Long userId;
    private String name;
    private String email;
    private String mobileNumber;
    private String vehicleNumber;

    // Getters and Setters

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getMobileNumber() {
        return mobileNumber;
    }

    public void setMobileNumber(String mobileNumber) {
        this.mobileNumber = mobileNumber;
    }

    public String getVehicleNumber() {
        return vehicleNumber;
    }

    public void setVehicleNumber(String vehicleNumber) {
        this.vehicleNumber = vehicleNumber;
    }

	public UserDTO(Long userId, String name, String email, String mobileNumber, String vehicleNumber) {
		super();
		this.userId = userId;
		this.name = name;
		this.email = email;
		this.mobileNumber = mobileNumber;
		this.vehicleNumber = vehicleNumber;
	}

	public UserDTO() {
		
		// TODO Auto-generated constructor stub
	}
    
    
}
