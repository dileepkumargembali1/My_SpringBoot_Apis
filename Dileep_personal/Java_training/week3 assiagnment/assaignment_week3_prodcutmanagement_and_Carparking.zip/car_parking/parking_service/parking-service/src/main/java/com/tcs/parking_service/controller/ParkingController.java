package com.tcs.parking_service.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.tcs.parking_service.entity.ParkingSlot;
import com.tcs.parking_service.service.ParkingService;

import java.util.*;

@RestController
@RequestMapping("/slots")
public class ParkingController {

    @Autowired
    private ParkingService parkingService;

    @GetMapping("/available")
    public List<ParkingSlot> getAvailableSlots() {
        return parkingService.getAvailableSlots();
    }

    @PostMapping("/book/{slotId}/{userId}")
    public ParkingSlot bookSlot(@PathVariable Long slotId, @PathVariable Long userId) {
        return parkingService.bookSlot(slotId, userId);
    }
    @PostMapping("/add")
    public ParkingSlot addSlot(@RequestBody ParkingSlot slot) {
        return parkingService.addSlot(slot);
    }

    @PostMapping("/release/{slotId}")
    public ParkingSlot releaseSlot(@PathVariable Long slotId) {
        return parkingService.releaseSlot(slotId);
    }

    @GetMapping("/history/{userId}")
    public List<ParkingSlot> getBookingHistory(@PathVariable Long userId) {
        return parkingService.getBookingHistory(userId);
    }
}
