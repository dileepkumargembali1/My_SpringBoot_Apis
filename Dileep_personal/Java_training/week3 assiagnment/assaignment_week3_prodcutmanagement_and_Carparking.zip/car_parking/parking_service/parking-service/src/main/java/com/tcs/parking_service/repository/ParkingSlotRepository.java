package com.tcs.parking_service.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.tcs.parking_service.entity.ParkingSlot;


import jakarta.persistence.LockModeType;

import java.util.*;
public interface ParkingSlotRepository extends JpaRepository<ParkingSlot, Long> {

    List<ParkingSlot> findByIsAvailableTrue();
    List<ParkingSlot> findByBookedByUser(Long userId);
    
    @Lock(LockModeType.PESSIMISTIC_WRITE)
    @Query("SELECT s FROM ParkingSlot s WHERE s.slotId = :slotId")
    Optional<ParkingSlot> findByIdForUpdate(@Param("slotId") Long slotId);
}
