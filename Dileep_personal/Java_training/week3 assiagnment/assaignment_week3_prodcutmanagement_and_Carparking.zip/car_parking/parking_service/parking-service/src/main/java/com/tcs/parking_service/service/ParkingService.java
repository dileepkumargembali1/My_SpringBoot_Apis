package com.tcs.parking_service.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tcs.parking_service.dto.UserDTO;
import com.tcs.parking_service.entity.ParkingSlot;
import com.tcs.parking_service.exception.SlotNotFoundException;
import com.tcs.parking_service.exception.SlotUnavailableException;
import com.tcs.parking_service.repository.ParkingSlotRepository;

import jakarta.transaction.Transactional;

import java.time.LocalDateTime;
import java.util.*;

@Service
public class ParkingService {

    @Autowired
    private ParkingSlotRepository repository;

    @Autowired
    private UserClient userClient;

    public List<ParkingSlot> getAvailableSlots() {
        return repository.findByIsAvailableTrue();
    }
    @Transactional
    public ParkingSlot bookSlot(Long slotId, Long userId) {
    	ParkingSlot slot = repository.findByIdForUpdate(slotId)
            .orElseThrow(() -> new SlotNotFoundException("Slot not found"));

        if (!slot.isAvailable()) {
            throw new SlotUnavailableException("Slot is already booked");
        }

        // Validate user using Feign
        UserDTO user = userClient.getUserById(userId);

        slot.setAvailable(false);
        slot.setBookedByUser(userId);
        slot.setBookingTime(LocalDateTime.now());
        
        return repository.save(slot);
    }

    public ParkingSlot releaseSlot(Long slotId) {
        ParkingSlot slot = repository.findById(slotId)
            .orElseThrow(() -> new SlotNotFoundException("Slot not found"));

        slot.setAvailable(true);
        slot.setBookedByUser(null);
        slot.setBookingTime(null);

        return repository.save(slot);
    }

    public List<ParkingSlot> getBookingHistory(Long userId) {
        return repository.findByBookedByUser(userId);
    }
    
    public ParkingSlot addSlot(ParkingSlot slot) {
       
        slot.setAvailable(true);
        slot.setBookedByUser(null);
        slot.setBookingTime(null);

        return repository.save(slot);
    }
    
}
