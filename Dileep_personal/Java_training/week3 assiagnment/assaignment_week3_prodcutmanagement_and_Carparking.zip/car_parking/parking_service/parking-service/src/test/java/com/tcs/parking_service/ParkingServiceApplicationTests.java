package com.tcs.parking_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ParkingServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
