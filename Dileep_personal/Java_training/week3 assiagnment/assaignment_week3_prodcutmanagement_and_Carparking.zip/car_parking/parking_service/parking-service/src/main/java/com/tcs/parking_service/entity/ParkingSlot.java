package com.tcs.parking_service.entity;

import java.time.LocalDateTime;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class ParkingSlot {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long slotId;

    private String location;
    private String slotNumber;
    private boolean isAvailable = true;
    private Long bookedByUser;
    private LocalDateTime bookingTime;
    
    
	public ParkingSlot(Long slotId, String location, String slotNumber, boolean isAvailable, Long bookedByUser,
			LocalDateTime bookingTime) {
		super();
		this.slotId = slotId;
		this.location = location;
		this.slotNumber = slotNumber;
		this.isAvailable = isAvailable;
		this.bookedByUser = bookedByUser;
		this.bookingTime = bookingTime;
	}
	
	
	public ParkingSlot() {
		

	}


	public Long getSlotId() {
		return slotId;
	}
	public void setSlotId(Long slotId) {
		this.slotId = slotId;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getSlotNumber() {
		return slotNumber;
	}
	public void setSlotNumber(String slotNumber) {
		this.slotNumber = slotNumber;
	}
	public boolean isAvailable() {
		return isAvailable;
	}
	public void setAvailable(boolean isAvailable) {
		this.isAvailable = isAvailable;
	}
	public Long getBookedByUser() {
		return bookedByUser;
	}
	public void setBookedByUser(Long bookedByUser) {
		this.bookedByUser = bookedByUser;
	}
	public LocalDateTime getBookingTime() {
		return bookingTime;
	}
	public void setBookingTime(LocalDateTime bookingTime) {
		this.bookingTime = bookingTime;
	}

  
    
}
