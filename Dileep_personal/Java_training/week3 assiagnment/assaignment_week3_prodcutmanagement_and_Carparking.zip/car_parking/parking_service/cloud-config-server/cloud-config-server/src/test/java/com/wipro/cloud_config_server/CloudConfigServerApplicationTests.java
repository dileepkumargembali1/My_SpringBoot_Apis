package com.wipro.cloud_config_server;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CloudConfigServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
